﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloMvc.Services
{
    public interface IDateTimeIndicator
    {
        string GetNowIndicator(DateTime DateLookup);
    }
}
