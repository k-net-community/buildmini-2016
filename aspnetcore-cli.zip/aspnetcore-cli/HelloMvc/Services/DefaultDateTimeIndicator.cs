﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HelloMvc.Services
{
    public class DefaultDateTimeIndicator : IDateTimeIndicator
    {
        public string GetNowIndicator(DateTime DateLookup)
        {
            TimeSpan ts = DateTime.Now - DateLookup;

            if (ts.Days == 0 && ts.Hours == 0 && ts.Minutes == 0)
                return string.Format("Before {0} seconds", ts.Seconds);
            else if (ts.Days == 0 && ts.Hours == 0)
                return string.Format("Before {0} minutes", ts.Minutes);
            else if (ts.Days == 0)
                return string.Format("Before {0} hours", ts.Hours);
            else
                return string.Format("Before {0} days", ts.Days);
        }
    }
}
